# Connecting Anvesha Form → Google Sheets

Follow these steps to wire the registration form to your Google Sheet:
`https://docs.google.com/spreadsheets/d/1L4p_Jp1Tla51RqkJW5ZZCIlYhLBEDufRqWVTB96ND0o`

---

## Step 1 — Add a header row to your Sheet

In **Row 1** of the sheet, add these column headers (in this exact order):

| A | B | C | D | E | F | G | H | I | J | K | L | M | N | O | P |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Timestamp | Full Name | Roll No | Email | Phone | Dept/Class | Category | Movie Inspiration | Act Description | Track Name | Track Link | Track Start | Track End | BG Preference | Track Notes | Ramp Walk |

---

## Step 2 — Create a Google Apps Script

1. Open your Google Sheet.
2. Click **Extensions → Apps Script**.
3. Delete any existing code and paste the following:

```javascript
function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    var data = JSON.parse(e.postData.contents);
    sheet.appendRow([
      data.timestamp,
      data.fullname,
      data.rollno,
      data.email,
      data.phone,
      data.deptclass,
      data.category,
      data.movieinspiration,
      data.actdesc,
      data.trackname,
      data.tracklink,
      data.trackstart,
      data.trackend,
      data.bgpref,
      data.tracknotes,
      data.rampwalk
    ]);
    return ContentService
      .createTextOutput(JSON.stringify({ result: "success" }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService
      .createTextOutput(JSON.stringify({ result: "error", message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
```

4. Click **Save** (name the project anything, e.g. "Anvesha Form Handler").

---

## Step 3 — Deploy as a Web App

1. Click **Deploy → New deployment**.
2. Click the gear icon ⚙️ next to "Select type" and choose **Web app**.
3. Set:
   - **Description**: Anvesha 2026 Form
   - **Execute as**: Me
   - **Who has access**: **Anyone** (this allows the form to post without login)
4. Click **Deploy**.
5. Authorise the script when prompted.
6. **Copy the Web App URL** — it looks like:
   `https://script.google.com/macros/s/AKfycb.../exec`

---

## Step 4 — Paste the URL into script.js

Open `script.js` and replace the placeholder on line 4:

```js
// BEFORE
const SHEET_URL = "YOUR_APPS_SCRIPT_WEB_APP_URL_HERE";

// AFTER
const SHEET_URL = "https://script.google.com/macros/s/AKfycb.../exec";
```

---

## Step 5 — Redeploy to Netlify

Upload the updated `script.js` (and the other files) back to Netlify:
- Go to your Netlify site dashboard → **Deploys** → drag-and-drop the `Anvesha/` folder, or push to your connected Git repo.

---

## Done! 🎉

Every form submission will now appear as a new row in your Google Sheet automatically.
